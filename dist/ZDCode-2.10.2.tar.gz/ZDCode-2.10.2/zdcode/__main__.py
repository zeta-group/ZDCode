from . import program

program.main()